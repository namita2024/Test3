# calculator
A calculator made in UWP with C# like the Windows Calculator Standard

## how to run
Intall Visual Studio with UWP, open the project and press F5

## see working
![calculator](https://user-images.githubusercontent.com/62714153/104793818-bd67e600-5782-11eb-81b0-a78c5c4cf6d1.gif)